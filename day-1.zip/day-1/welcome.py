# show print message
print("welcome to python")

# python variable declarations (dynamic type instead of static type)

a=10
name="hello"
name=23.40

#-----------

myname="Amarjeet"
city='pune'
pin=12345

print(f"MY name is {myname} and city  is {city} and the pincode belongs to {pin}")

# python indentation
if 10 >5:
    print("this is true")
print("something else")

 

