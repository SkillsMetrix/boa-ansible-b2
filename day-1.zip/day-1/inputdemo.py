

 


valueA = int(input("Please enter first value: "))
valueB = int(input("Please enter Sec value: "))

c=valueA+valueB
# {} -> used for expression in output
print(f"Addition is {c}")