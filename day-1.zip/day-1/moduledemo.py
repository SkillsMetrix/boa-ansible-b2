
from math import sqrt

from mainfile import add,sub

print(add(12,13))

print(sqrt(4))

